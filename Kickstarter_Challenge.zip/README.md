# Kickstarter-Challenge
## Miguel Fidelino August 27 2022.